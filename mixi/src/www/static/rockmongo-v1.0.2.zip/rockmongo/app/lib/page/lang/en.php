<?php
/**
 * en_us的配置
 * 
 * @since 1.0
 * @package if
 * @subpackage plugin.pager.lang
 */
$message["pager_prev"] = "Prev";
$message["pager_next"] = "Next";
$message["pager_first"] = "First";
$message["pager_last"] = "Last";
$message["pager_input_pageno"] = "Turn To:";
$message["pager_current_pageno"] = "Current: %d ";
$message["pager_total_page"] = "Total: %d ";

?>