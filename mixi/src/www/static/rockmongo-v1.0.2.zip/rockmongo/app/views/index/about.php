<strong class="big">RockMongo</strong> is a MongoDB management and admin tool, written in PHP 5.

<p>See <a href="http://code.google.com/p/rock-php/wiki/rock_mongo" target="_blank">http://code.google.com/p/rock-php/wiki/rock_mongo</a> for more details.</p>

<p>If you have any question, please send me email: <a href="mailto:iwind.liu@gmail.com">iwind.liu@gmail.com</a> .</p>