<p class="message"><?php h($db);?> &raquo; <?php h($collection);?> is dropped from database.</p>
<script language="javascript">
window.top.frames["left"].location.reload();
</script>